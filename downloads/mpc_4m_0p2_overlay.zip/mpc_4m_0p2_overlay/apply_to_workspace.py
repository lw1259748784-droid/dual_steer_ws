#!/usr/bin/env python3
"""Apply the verified MPC source overlay without replacing route points."""

from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import sys


bundle = Path(__file__).resolve().parent
workspace = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else Path.home() / 'dual_steer_ws'
manifest = json.loads((bundle / 'manifest.json').read_text(encoding='utf-8'))
route = workspace / 'routes/current_route.yaml'

if not (workspace / 'src/nav2_humble/package.xml').is_file() or not route.is_file():
    raise SystemExit(f'找不到完整工作区或路线文件：{workspace}')
if route.is_symlink():
    raise SystemExit('路线文件是符号链接，请手动核对后再修改')

to_copy = []
for relative, hashes in manifest.items():
    target = workspace / relative
    payload = bundle / 'payload' / relative
    if not target.is_file() or target.is_symlink():
        raise SystemExit(f'缺少源码文件或文件是符号链接：{target}')
    if sha256(payload.read_bytes()).hexdigest() != hashes['after']:
        raise SystemExit(f'下载的更新包校验失败：{payload}')
    current = sha256(target.read_bytes()).hexdigest()
    if current == hashes['before']:
        to_copy.append((payload, target, relative))
    elif current != hashes['after']:
        raise SystemExit(f'本机文件与上传版本不同，未覆盖：{target}')

original_route = route.read_text(encoding='utf-8')
updated_route, speed_count = re.subn(
    r'(?m)^([ \t]*speed_limit:[ \t]*)[-+]?\d+(?:\.\d+)?([ \t]*)$',
    r'\g<1>0.20\g<2>', original_route)
if speed_count == 0:
    raise SystemExit('路线中没有转弯 speed_limit，未修改任何文件')

if not to_copy and updated_route == original_route:
    print('这些修改已经在本机，无需重复应用')
    raise SystemExit(0)

stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
backup = workspace.parent / f'{workspace.name}_before_mpc_4m_0p2_{stamp}'
for _, target, relative in to_copy:
    saved = backup / relative
    saved.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(target, saved)
if updated_route != original_route:
    saved = backup / 'routes/current_route.yaml'
    saved.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(route, saved)

for payload, target, relative in to_copy:
    temp = target.with_name(target.name + '.mpc_update_tmp')
    shutil.copy2(payload, temp)
    temp.replace(target)
    print('已更新：', relative)
if updated_route != original_route:
    temp = route.with_name(route.name + '.mpc_update_tmp')
    temp.write_text(updated_route, encoding='utf-8')
    temp.replace(route)
    print('已更新：routes/current_route.yaml 的转弯速度元数据；P 点未改动')
print('备份目录：', backup)
print('完成。请重新构建并重启 Nav2、路径编辑器和 RViz。')
