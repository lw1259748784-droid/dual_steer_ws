#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <limits>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <sys/types.h>

#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/point_stamped.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <nav_msgs/msg/path.hpp>
#include <std_srvs/srv/trigger.hpp>
#include <visualization_msgs/msg/marker.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <tf2/LinearMath/Quaternion.h>

class RVizPathEditor : public rclcpp::Node
{
public:
  RVizPathEditor() : Node("rviz_path_editor")
  {
    declare_parameter<std::string>("frame_id", "map");
    declare_parameter<std::string>("clicked_point_topic", "/clicked_point");
    declare_parameter<std::string>("path_topic", "/global_path");
    declare_parameter<std::string>("marker_topic", "/path_editor/markers");
    declare_parameter<double>("resolution", 0.20);
    declare_parameter<double>("publish_rate", 5.0);

    // ------------------------------------------------------------------
    // Route persistence parameters
    // ------------------------------------------------------------------
    // The route stores ONLY the manually clicked semantic control points.
    // Automatic turnaround samples are generated at runtime and are NOT
    // saved as P-points and are NOT published as point markers.
    declare_parameter<std::string>(
      "route_file", "/home/tl/dual_steer_ws/routes/current_route.yaml");
    declare_parameter<bool>("auto_save", true);
    declare_parameter<bool>("auto_load", true);

    // ------------------------------------------------------------------
    // Parameters controlled by the RViz2 Route Editor panel.
    // Select a type in the panel, then use RViz "Publish Point".
    // ------------------------------------------------------------------
    declare_parameter<std::string>("current_point_type", "waypoint");
    declare_parameter<std::string>("turn_direction", "left");
    declare_parameter<double>("turn_min_turning_radius", 2.80);
    declare_parameter<double>("turn_speed_limit", 0.20);
    declare_parameter<double>("turn_resolution", 0.10);

    frame_id_ = get_parameter("frame_id").as_string();
    const auto clicked_topic = get_parameter("clicked_point_topic").as_string();
    const auto path_topic = get_parameter("path_topic").as_string();
    const auto marker_topic = get_parameter("marker_topic").as_string();
    resolution_ = std::max(0.05, get_parameter("resolution").as_double());
    const double publish_rate =
      std::max(0.5, get_parameter("publish_rate").as_double());

    route_file_ = get_parameter("route_file").as_string();
    auto_save_ = get_parameter("auto_save").as_bool();
    auto_load_ = get_parameter("auto_load").as_bool();

    point_sub_ = create_subscription<geometry_msgs::msg::PointStamped>(
      clicked_topic, rclcpp::QoS(10),
      std::bind(&RVizPathEditor::pointCallback, this, std::placeholders::_1));

    path_pub_ = create_publisher<nav_msgs::msg::Path>(
      path_topic, rclcpp::QoS(1).reliable().transient_local());
    marker_pub_ = create_publisher<visualization_msgs::msg::MarkerArray>(
      marker_topic, rclcpp::QoS(1).reliable().transient_local());

    clear_srv_ = create_service<std_srvs::srv::Trigger>(
      "/path_editor/clear",
      std::bind(
        &RVizPathEditor::clearPath, this,
        std::placeholders::_1, std::placeholders::_2));
    undo_srv_ = create_service<std_srvs::srv::Trigger>(
      "/path_editor/undo",
      std::bind(
        &RVizPathEditor::undoPoint, this,
        std::placeholders::_1, std::placeholders::_2));
    save_srv_ = create_service<std_srvs::srv::Trigger>(
      "/path_editor/save",
      std::bind(
        &RVizPathEditor::saveRouteService, this,
        std::placeholders::_1, std::placeholders::_2));
    load_srv_ = create_service<std_srvs::srv::Trigger>(
      "/path_editor/load",
      std::bind(
        &RVizPathEditor::loadRouteService, this,
        std::placeholders::_1, std::placeholders::_2));

    timer_ = create_wall_timer(
      std::chrono::duration<double>(1.0 / publish_rate),
      std::bind(&RVizPathEditor::publishAll, this));

    RCLCPP_INFO(
      get_logger(),
      "RViz path editor ready: click '%s' -> path '%s' (resolution %.2fm).",
      clicked_topic.c_str(), path_topic.c_str(), resolution_);
    RCLCPP_INFO(
      get_logger(),
      "Services: /path_editor/undo, /path_editor/clear, "
      "/path_editor/save, /path_editor/load");
    RCLCPP_INFO(
      get_logger(),
      "Route persistence: file='%s', auto_save=%s, auto_load=%s",
      route_file_.c_str(),
      auto_save_ ? "true" : "false",
      auto_load_ ? "true" : "false");

    RCLCPP_INFO(
      get_logger(),
      "Semantic editing enabled: current_point_type=%s, turn_direction=%s, "
      "Rmin=%.2fm, turn_speed=%.2fm/s",
      get_parameter("current_point_type").as_string().c_str(),
      get_parameter("turn_direction").as_string().c_str(),
      get_parameter("turn_min_turning_radius").as_double(),
      get_parameter("turn_speed_limit").as_double());

    if (auto_load_) {
      if (fileExists(route_file_)) {
        std::string message;
        if (loadRouteFromDisk(message)) {
          RCLCPP_INFO(get_logger(), "Auto-load: %s", message.c_str());
        } else {
          RCLCPP_WARN(get_logger(), "Auto-load failed: %s", message.c_str());
        }
      } else {
        RCLCPP_INFO(
          get_logger(),
          "Auto-load: no saved route yet at '%s'.",
          route_file_.c_str());
      }
    }
  }

private:
  static constexpr double twoPi()
  {
    return 6.28318530717958647692;
  }

  struct RoutePoint
  {
    int id{0};
    geometry_msgs::msg::Point point;
    std::string type{"waypoint"};
  };

  struct TurnaroundSegment
  {
    int from_id{0};
    int to_id{0};
    std::string direction{"auto"};  // auto / left / right
    double min_turning_radius{2.80};
    double speed_limit{0.20};      // metadata for future speed control
    double resolution{0.10};
  };

  struct DubinsCandidate
  {
    bool valid{false};
    std::string word;
    std::array<double, 3> params{{0.0, 0.0, 0.0}};
    double cost{std::numeric_limits<double>::infinity()};
  };

  std::string frame_id_;
  double resolution_{0.20};
  std::vector<RoutePoint> route_points_;
  std::vector<TurnaroundSegment> turnarounds_;

  std::string route_file_;
  bool auto_save_{true};
  bool auto_load_{true};

  rclcpp::Subscription<geometry_msgs::msg::PointStamped>::SharedPtr point_sub_;
  rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr marker_pub_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr clear_srv_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr undo_srv_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr save_srv_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr load_srv_;
  rclcpp::TimerBase::SharedPtr timer_;

  // ------------------------------------------------------------------
  // Generic helpers
  // ------------------------------------------------------------------
  static double mod2pi(double value)
  {
    double result = std::fmod(value, twoPi());
    if (result < 0.0) {
      result += twoPi();
    }
    return result;
  }

  static std::string lower(std::string value)
  {
    std::transform(
      value.begin(), value.end(), value.begin(),
      [](unsigned char c) {return static_cast<char>(std::tolower(c));});
    return value;
  }

  static bool fileExists(const std::string & path)
  {
    struct stat info;
    return ::stat(path.c_str(), &info) == 0 && S_ISREG(info.st_mode);
  }

  static std::string trim(const std::string & input)
  {
    const auto first = input.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) {
      return "";
    }
    const auto last = input.find_last_not_of(" \t\r\n");
    return input.substr(first, last - first + 1);
  }

  static bool startsWith(const std::string & text, const std::string & prefix)
  {
    return text.size() >= prefix.size() &&
           text.compare(0, prefix.size(), prefix) == 0;
  }

  static std::string stringAfterColon(const std::string & line)
  {
    const auto colon = line.find(':');
    if (colon == std::string::npos) {
      return "";
    }
    std::string value = trim(line.substr(colon + 1));
    if (value.size() >= 2) {
      const char a = value.front();
      const char b = value.back();
      if ((a == '"' && b == '"') || (a == '\'' && b == '\'')) {
        value = value.substr(1, value.size() - 2);
      }
    }
    return value;
  }

  static bool parseDoubleAfterColon(const std::string & line, double & value)
  {
    try {
      value = std::stod(stringAfterColon(line));
      return true;
    } catch (...) {
      return false;
    }
  }

  static bool parseIntAfterColon(const std::string & line, int & value)
  {
    try {
      value = std::stoi(stringAfterColon(line));
      return true;
    } catch (...) {
      return false;
    }
  }

  bool ensureRouteDirectory(std::string & error_message)
  {
    const auto slash = route_file_.find_last_of('/');
    if (slash == std::string::npos || slash == 0) {
      return true;
    }

    const std::string directory = route_file_.substr(0, slash);
    struct stat info;
    if (::stat(directory.c_str(), &info) == 0) {
      if (S_ISDIR(info.st_mode)) {
        return true;
      }
      error_message =
        "Route parent exists but is not a directory: " + directory;
      return false;
    }

    if (::mkdir(directory.c_str(), 0755) == 0 || errno == EEXIST) {
      return true;
    }

    error_message =
      "Cannot create route directory '" + directory + "': " +
      std::strerror(errno);
    return false;
  }

  static bool copyFile(
    const std::string & source,
    const std::string & destination)
  {
    std::ifstream in(source.c_str(), std::ios::binary);
    if (!in.is_open()) {
      return false;
    }

    std::ofstream out(
      destination.c_str(),
      std::ios::binary | std::ios::trunc);
    if (!out.is_open()) {
      return false;
    }

    out << in.rdbuf();
    return out.good();
  }

  int nextPointId() const
  {
    int max_id = 0;
    for (const auto & p : route_points_) {
      max_id = std::max(max_id, p.id);
    }
    return max_id + 1;
  }

  int pointIndexById(int id) const
  {
    for (size_t i = 0; i < route_points_.size(); ++i) {
      if (route_points_[i].id == id) {
        return static_cast<int>(i);
      }
    }
    return -1;
  }

  const TurnaroundSegment * findTurnaround(int from_id, int to_id) const
  {
    for (const auto & turn : turnarounds_) {
      if (turn.from_id == from_id && turn.to_id == to_id) {
        return &turn;
      }
    }
    return nullptr;
  }

  // ------------------------------------------------------------------
  // Persistence
  // ------------------------------------------------------------------
  bool saveRouteToDisk(std::string & message)
  {
    std::string error_message;
    if (!ensureRouteDirectory(error_message)) {
      message = error_message;
      return false;
    }

    if (fileExists(route_file_)) {
      const std::string backup_file = route_file_ + ".bak";
      if (!copyFile(route_file_, backup_file)) {
        RCLCPP_WARN(
          get_logger(),
          "Could not update route backup '%s'. Continuing with main save.",
          backup_file.c_str());
      }
    }

    const std::string temp_file = route_file_ + ".tmp";
    std::ofstream out(
      temp_file.c_str(),
      std::ios::out | std::ios::trunc);
    if (!out.is_open()) {
      message =
        "Cannot open temporary route file for writing: " + temp_file;
      return false;
    }

    out << "# RVizPathEditor semantic persistent route\n";
    out << "# Only semantic control points are saved. Automatic turnaround "
           "samples are generated at runtime.\n";
    out << "frame_id: " << frame_id_ << "\n";
    out << "point_count: " << route_points_.size() << "\n";
    out << "points:\n";
    out << std::setprecision(17);

    for (const auto & p : route_points_) {
      out << "  - id: " << p.id << "\n";
      out << "    x: " << p.point.x << "\n";
      out << "    y: " << p.point.y << "\n";
      out << "    z: " << p.point.z << "\n";
      out << "    type: " << p.type << "\n";
    }

    out << "\nturnarounds:\n";
    for (const auto & turn : turnarounds_) {
      out << "  - from_id: " << turn.from_id << "\n";
      out << "    to_id: " << turn.to_id << "\n";
      out << "    direction: " << turn.direction << "\n";
      out << "    min_turning_radius: " << turn.min_turning_radius << "\n";
      out << "    speed_limit: " << turn.speed_limit << "\n";
      out << "    resolution: " << turn.resolution << "\n";
    }

    out.flush();
    if (!out.good()) {
      out.close();
      std::remove(temp_file.c_str());
      message = "Failed while writing route file: " + temp_file;
      return false;
    }
    out.close();

    if (std::rename(temp_file.c_str(), route_file_.c_str()) != 0) {
      const std::string err = std::strerror(errno);
      std::remove(temp_file.c_str());
      message =
        "Cannot replace route file '" + route_file_ + "': " + err;
      return false;
    }

    std::ostringstream ss;
    ss << "Saved " << route_points_.size() << " semantic point(s), "
       << turnarounds_.size() << " turnaround(s) to " << route_file_;
    message = ss.str();
    return true;
  }

  bool validateLoadedRoute(
    const std::vector<RoutePoint> & points,
    const std::vector<TurnaroundSegment> & turns,
    std::string & message) const
  {
    if (points.empty()) {
      message = "Saved route contains no complete points: " + route_file_;
      return false;
    }

    for (size_t i = 0; i < points.size(); ++i) {
      if (points[i].id <= 0) {
        message = "Route point id must be positive.";
        return false;
      }
      for (size_t j = i + 1; j < points.size(); ++j) {
        if (points[i].id == points[j].id) {
          message =
            "Duplicate route point id: P" + std::to_string(points[i].id);
          return false;
        }
      }
    }

    for (const auto & turn : turns) {
      int from_index = -1;
      int to_index = -1;
      for (size_t i = 0; i < points.size(); ++i) {
        if (points[i].id == turn.from_id) {
          from_index = static_cast<int>(i);
        }
        if (points[i].id == turn.to_id) {
          to_index = static_cast<int>(i);
        }
      }

      if (from_index < 0 || to_index < 0) {
        message =
          "Turnaround references missing point: P" +
          std::to_string(turn.from_id) + " -> P" +
          std::to_string(turn.to_id);
        return false;
      }

      // The editor replaces exactly one adjacency in the semantic route.
      if (to_index != from_index + 1) {
        message =
          "Turnaround endpoints must be adjacent in points[]: P" +
          std::to_string(turn.from_id) + " -> P" +
          std::to_string(turn.to_id);
        return false;
      }

      if (turn.min_turning_radius <= 0.0 || turn.resolution <= 0.0) {
        message =
          "Turnaround radius/resolution must be positive for P" +
          std::to_string(turn.from_id) + " -> P" +
          std::to_string(turn.to_id);
        return false;
      }
    }

    return true;
  }

  bool loadRouteFromDisk(std::string & message)
  {
    std::ifstream in(route_file_.c_str());
    if (!in.is_open()) {
      message = "Cannot open saved route: " + route_file_;
      return false;
    }

    enum class Section
    {
      NONE,
      POINTS,
      TURNAROUNDS
    };

    Section section = Section::NONE;
    std::vector<RoutePoint> loaded_points;
    std::vector<TurnaroundSegment> loaded_turns;

    RoutePoint current_point;
    bool point_started = false;
    bool have_x = false;
    bool have_y = false;

    TurnaroundSegment current_turn;
    bool turn_started = false;
    bool have_from = false;
    bool have_to = false;

    std::string saved_frame;
    int legacy_next_id = 1;

    auto commit_point = [&]() -> bool {
      if (!point_started) {
        return true;
      }

      if (!have_x || !have_y) {
        message = "Incomplete point in route YAML.";
        return false;
      }

      if (current_point.id <= 0) {
        current_point.id = legacy_next_id;
      }
      legacy_next_id = std::max(legacy_next_id, current_point.id + 1);

      if (current_point.type.empty()) {
        current_point.type = "waypoint";
      }

      loaded_points.push_back(current_point);
      current_point = RoutePoint();
      point_started = false;
      have_x = false;
      have_y = false;
      return true;
    };

    auto commit_turn = [&]() -> bool {
      if (!turn_started) {
        return true;
      }

      if (!have_from || !have_to) {
        message = "Incomplete turnaround in route YAML.";
        return false;
      }

      if (current_turn.direction.empty()) {
        current_turn.direction = "auto";
      }

      loaded_turns.push_back(current_turn);
      current_turn = TurnaroundSegment();
      turn_started = false;
      have_from = false;
      have_to = false;
      return true;
    };

    std::string raw_line;
    std::size_t line_number = 0;

    while (std::getline(in, raw_line)) {
      ++line_number;
      const std::string line = trim(raw_line);

      if (line.empty() || line[0] == '#') {
        continue;
      }

      if (startsWith(line, "frame_id:")) {
        saved_frame = stringAfterColon(line);
        continue;
      }

      if (line == "points:") {
        if (!commit_turn()) {
          return false;
        }
        section = Section::POINTS;
        continue;
      }

      if (line == "turnarounds:") {
        if (!commit_point()) {
          return false;
        }
        section = Section::TURNAROUNDS;
        continue;
      }

      if (section == Section::POINTS) {
        if (startsWith(line, "- id:")) {
          if (!commit_point()) {
            return false;
          }

          current_point = RoutePoint();
          current_point.point.z = 0.0;
          point_started = true;
          have_x = false;
          have_y = false;

          if (!parseIntAfterColon(line, current_point.id)) {
            message =
              "Invalid point id at line " + std::to_string(line_number);
            return false;
          }
          continue;
        }

        // Backward compatibility with the old format:
        //   - x: ...
        //     y: ...
        //     z: ...
        if (startsWith(line, "- x:")) {
          if (!commit_point()) {
            return false;
          }

          current_point = RoutePoint();
          current_point.id = legacy_next_id;
          current_point.type = "waypoint";
          current_point.point.z = 0.0;
          point_started = true;
          have_x = false;
          have_y = false;

          if (!parseDoubleAfterColon(line, current_point.point.x)) {
            message =
              "Invalid x value at line " + std::to_string(line_number);
            return false;
          }
          have_x = true;
          continue;
        }

        if (!point_started) {
          continue;
        }

        if (startsWith(line, "x:")) {
          if (!parseDoubleAfterColon(line, current_point.point.x)) {
            message =
              "Invalid x value at line " + std::to_string(line_number);
            return false;
          }
          have_x = true;
          continue;
        }

        if (startsWith(line, "y:")) {
          if (!parseDoubleAfterColon(line, current_point.point.y)) {
            message =
              "Invalid y value at line " + std::to_string(line_number);
            return false;
          }
          have_y = true;
          continue;
        }

        if (startsWith(line, "z:")) {
          if (!parseDoubleAfterColon(line, current_point.point.z)) {
            message =
              "Invalid z value at line " + std::to_string(line_number);
            return false;
          }
          continue;
        }

        if (startsWith(line, "type:")) {
          current_point.type = stringAfterColon(line);
          continue;
        }
      }

      if (section == Section::TURNAROUNDS) {
        if (startsWith(line, "- from_id:")) {
          if (!commit_turn()) {
            return false;
          }

          current_turn = TurnaroundSegment();
          turn_started = true;
          have_from = false;
          have_to = false;

          if (!parseIntAfterColon(line, current_turn.from_id)) {
            message =
              "Invalid turnaround from_id at line " +
              std::to_string(line_number);
            return false;
          }
          have_from = true;
          continue;
        }

        if (!turn_started) {
          continue;
        }

        if (startsWith(line, "to_id:")) {
          if (!parseIntAfterColon(line, current_turn.to_id)) {
            message =
              "Invalid turnaround to_id at line " +
              std::to_string(line_number);
            return false;
          }
          have_to = true;
          continue;
        }

        if (startsWith(line, "direction:")) {
          current_turn.direction = lower(stringAfterColon(line));
          continue;
        }

        if (startsWith(line, "min_turning_radius:")) {
          if (!parseDoubleAfterColon(
              line, current_turn.min_turning_radius))
          {
            message =
              "Invalid min_turning_radius at line " +
              std::to_string(line_number);
            return false;
          }
          continue;
        }

        if (startsWith(line, "speed_limit:")) {
          if (!parseDoubleAfterColon(line, current_turn.speed_limit)) {
            message =
              "Invalid speed_limit at line " +
              std::to_string(line_number);
            return false;
          }
          continue;
        }

        if (startsWith(line, "resolution:")) {
          if (!parseDoubleAfterColon(line, current_turn.resolution)) {
            message =
              "Invalid turnaround resolution at line " +
              std::to_string(line_number);
            return false;
          }
          continue;
        }
      }
    }

    if (!commit_point() || !commit_turn()) {
      return false;
    }

    if (!saved_frame.empty() && saved_frame != frame_id_) {
      message =
        "Saved route frame '" + saved_frame +
        "' does not match current frame '" + frame_id_ + "'.";
      return false;
    }

    if (!validateLoadedRoute(loaded_points, loaded_turns, message)) {
      return false;
    }

    route_points_ = loaded_points;
    turnarounds_ = loaded_turns;
    publishAll();

    std::ostringstream ss;
    ss << "Loaded " << route_points_.size() << " semantic point(s), "
       << turnarounds_.size() << " turnaround(s) from " << route_file_
       << " and rebuilt /global_path.";
    message = ss.str();
    return true;
  }

  // ------------------------------------------------------------------
  // Point editing
  // ------------------------------------------------------------------
  void pointCallback(
    const geometry_msgs::msg::PointStamped::SharedPtr msg)
  {
    if (!msg->header.frame_id.empty() &&
        msg->header.frame_id != frame_id_)
    {
      RCLCPP_WARN(
        get_logger(),
        "Ignoring clicked point in frame '%s'; RViz Fixed Frame should be '%s'.",
        msg->header.frame_id.c_str(), frame_id_.c_str());
      return;
    }

    std::string point_type =
      lower(get_parameter("current_point_type").as_string());

    const bool valid_type =
      point_type == "start" ||
      point_type == "waypoint" ||
      point_type == "hutch_stop" ||
      point_type == "turn_entry" ||
      point_type == "turn_exit" ||
      point_type == "goal";

    if (!valid_type) {
      RCLCPP_WARN(
        get_logger(),
        "Unknown current_point_type='%s'; using waypoint.",
        point_type.c_str());
      point_type = "waypoint";
    }

    // Keep START and GOAL unique. If the user selects a new one,
    // demote the old one to a normal waypoint.
    if (point_type == "start" || point_type == "goal") {
      for (auto & existing : route_points_) {
        if (existing.type == point_type) {
          existing.type = "waypoint";
        }
      }
    }

    RoutePoint p;
    p.id = nextPointId();
    p.point = msg->point;
    p.point.z = 0.0;
    p.type = point_type;

    route_points_.push_back(p);

    // A turnaround is created automatically when TURN_OUT is clicked
    // immediately after TURN_IN. No manually clicked points are allowed
    // between these two semantic endpoints.
    if (p.type == "turn_exit") {
      if (route_points_.size() >= 2) {
        const auto & previous = route_points_[route_points_.size() - 2];

        if (previous.type == "turn_entry") {
          TurnaroundSegment turn;
          turn.from_id = previous.id;
          turn.to_id = p.id;

          turn.direction =
            lower(get_parameter("turn_direction").as_string());
          if (turn.direction != "left" &&
              turn.direction != "right" &&
              turn.direction != "auto")
          {
            turn.direction = "auto";
          }

          turn.min_turning_radius = std::max(
            0.10,
            get_parameter("turn_min_turning_radius").as_double());
          turn.speed_limit = std::max(
            0.0,
            get_parameter("turn_speed_limit").as_double());
          turn.resolution = std::max(
            0.02,
            get_parameter("turn_resolution").as_double());

          turnarounds_.push_back(turn);

          RCLCPP_INFO(
            get_logger(),
            "Created turnaround P%d -> P%d: direction=%s, "
            "Rmin=%.2fm, speed_limit=%.2fm/s, resolution=%.2fm",
            turn.from_id,
            turn.to_id,
            turn.direction.c_str(),
            turn.min_turning_radius,
            turn.speed_limit,
            turn.resolution);
        } else {
          RCLCPP_WARN(
            get_logger(),
            "P%d is TURN_OUT, but previous point P%d is type '%s'. "
            "TURN_OUT should be clicked immediately after TURN_IN.",
            p.id,
            previous.id,
            previous.type.c_str());
        }
      } else {
        RCLCPP_WARN(
          get_logger(),
          "TURN_OUT cannot be the first route point.");
      }
    }

    RCLCPP_INFO(
      get_logger(),
      "Added P%d: x=%.3f, y=%.3f, type=%s",
      p.id, p.point.x, p.point.y, p.type.c_str());

    publishAll();

    if (auto_save_) {
      std::string message;
      if (saveRouteToDisk(message)) {
        RCLCPP_INFO(get_logger(), "Auto-save: %s", message.c_str());
      } else {
        RCLCPP_ERROR(
          get_logger(), "Auto-save failed: %s", message.c_str());
      }
    }
  }

  // ------------------------------------------------------------------
  // Dubins generator
  //
  // The path is generated from:
  //   start = turn_entry position + previous straight segment heading
  //   goal  = turn_exit position  + next straight segment heading
  //
  // Curvature magnitude never exceeds 1 / min_turning_radius.
  // ------------------------------------------------------------------
  static bool dubinsLSL(
    double alpha, double beta, double d,
    std::array<double, 3> & out)
  {
    const double tmp0 =
      d + std::sin(alpha) - std::sin(beta);
    const double p2 =
      2.0 + d * d - 2.0 * std::cos(alpha - beta) +
      2.0 * d * (std::sin(alpha) - std::sin(beta));

    if (p2 < -1e-10) {
      return false;
    }

    const double p = std::sqrt(std::max(0.0, p2));
    const double tmp1 =
      std::atan2(
        std::cos(beta) - std::cos(alpha),
        tmp0);

    out = {{
      mod2pi(-alpha + tmp1),
      p,
      mod2pi(beta - tmp1)
    }};
    return true;
  }

  static bool dubinsRSR(
    double alpha, double beta, double d,
    std::array<double, 3> & out)
  {
    const double tmp0 =
      d - std::sin(alpha) + std::sin(beta);
    const double p2 =
      2.0 + d * d - 2.0 * std::cos(alpha - beta) +
      2.0 * d * (-std::sin(alpha) + std::sin(beta));

    if (p2 < -1e-10) {
      return false;
    }

    const double p = std::sqrt(std::max(0.0, p2));
    const double tmp1 =
      std::atan2(
        std::cos(alpha) - std::cos(beta),
        tmp0);

    out = {{
      mod2pi(alpha - tmp1),
      p,
      mod2pi(-beta + tmp1)
    }};
    return true;
  }

  static bool dubinsLSR(
    double alpha, double beta, double d,
    std::array<double, 3> & out)
  {
    const double p2 =
      -2.0 + d * d + 2.0 * std::cos(alpha - beta) +
      2.0 * d * (std::sin(alpha) + std::sin(beta));

    if (p2 < -1e-10) {
      return false;
    }

    const double p = std::sqrt(std::max(0.0, p2));
    const double tmp2 =
      std::atan2(
        -std::cos(alpha) - std::cos(beta),
        d + std::sin(alpha) + std::sin(beta)) -
      std::atan2(-2.0, p);

    out = {{
      mod2pi(-alpha + tmp2),
      p,
      mod2pi(-beta + tmp2)
    }};
    return true;
  }

  static bool dubinsRSL(
    double alpha, double beta, double d,
    std::array<double, 3> & out)
  {
    const double p2 =
      d * d - 2.0 + 2.0 * std::cos(alpha - beta) -
      2.0 * d * (std::sin(alpha) + std::sin(beta));

    if (p2 < -1e-10) {
      return false;
    }

    const double p = std::sqrt(std::max(0.0, p2));
    const double tmp2 =
      std::atan2(
        std::cos(alpha) + std::cos(beta),
        d - std::sin(alpha) - std::sin(beta)) -
      std::atan2(2.0, p);

    out = {{
      mod2pi(alpha - tmp2),
      p,
      mod2pi(beta - tmp2)
    }};
    return true;
  }

  static bool dubinsRLR(
    double alpha, double beta, double d,
    std::array<double, 3> & out)
  {
    double tmp =
      (6.0 - d * d + 2.0 * std::cos(alpha - beta) +
       2.0 * d * (std::sin(alpha) - std::sin(beta))) / 8.0;

    if (tmp < -1.0 - 1e-10 || tmp > 1.0 + 1e-10) {
      return false;
    }

    tmp = std::max(-1.0, std::min(1.0, tmp));
    const double p =
      mod2pi(twoPi() - std::acos(tmp));

    const double t =
      mod2pi(
        alpha -
        std::atan2(
          std::cos(alpha) - std::cos(beta),
          d - std::sin(alpha) + std::sin(beta)) +
        p / 2.0);

    out = {{
      t,
      p,
      mod2pi(alpha - beta - t + p)
    }};
    return true;
  }

  static bool dubinsLRL(
    double alpha, double beta, double d,
    std::array<double, 3> & out)
  {
    double tmp =
      (6.0 - d * d + 2.0 * std::cos(alpha - beta) +
       2.0 * d * (-std::sin(alpha) + std::sin(beta))) / 8.0;

    if (tmp < -1.0 - 1e-10 || tmp > 1.0 + 1e-10) {
      return false;
    }

    tmp = std::max(-1.0, std::min(1.0, tmp));
    const double p =
      mod2pi(twoPi() - std::acos(tmp));

    const double t =
      mod2pi(
        -alpha -
        std::atan2(
          std::cos(alpha) - std::cos(beta),
          d + std::sin(alpha) - std::sin(beta)) +
        p / 2.0);

    out = {{
      t,
      p,
      mod2pi(beta - alpha - t + p)
    }};
    return true;
  }

  static DubinsCandidate makeCandidate(
    const std::string & word,
    bool valid,
    const std::array<double, 3> & params,
    double radius)
  {
    DubinsCandidate c;
    c.valid = valid;
    c.word = word;
    c.params = params;
    if (valid) {
      c.cost =
        radius * (params[0] + params[1] + params[2]);
    }
    return c;
  }

  static bool directionAccepts(
    const std::string & direction,
    const std::string & word)
  {
    if (word.empty()) {
      return false;
    }

    const std::string d = lower(direction);
    if (d == "left") {
      return word.front() == 'L';
    }
    if (d == "right") {
      return word.front() == 'R';
    }
    return true;
  }

  static bool planDubins(
    double sx, double sy, double syaw,
    double gx, double gy, double gyaw,
    double radius,
    const std::string & direction,
    DubinsCandidate & best)
  {
    if (radius <= 0.0) {
      return false;
    }

    const double dx = gx - sx;
    const double dy = gy - sy;
    const double distance = std::hypot(dx, dy);
    const double d = distance / radius;

    const double theta = std::atan2(dy, dx);
    const double alpha = mod2pi(syaw - theta);
    const double beta = mod2pi(gyaw - theta);

    std::vector<DubinsCandidate> candidates;
    candidates.reserve(6);

    std::array<double, 3> p{{0.0, 0.0, 0.0}};
    bool valid = false;

    valid = dubinsLSL(alpha, beta, d, p);
    candidates.push_back(makeCandidate("LSL", valid, p, radius));

    p = {{0.0, 0.0, 0.0}};
    valid = dubinsRSR(alpha, beta, d, p);
    candidates.push_back(makeCandidate("RSR", valid, p, radius));

    p = {{0.0, 0.0, 0.0}};
    valid = dubinsLSR(alpha, beta, d, p);
    candidates.push_back(makeCandidate("LSR", valid, p, radius));

    p = {{0.0, 0.0, 0.0}};
    valid = dubinsRSL(alpha, beta, d, p);
    candidates.push_back(makeCandidate("RSL", valid, p, radius));

    p = {{0.0, 0.0, 0.0}};
    valid = dubinsRLR(alpha, beta, d, p);
    candidates.push_back(makeCandidate("RLR", valid, p, radius));

    p = {{0.0, 0.0, 0.0}};
    valid = dubinsLRL(alpha, beta, d, p);
    candidates.push_back(makeCandidate("LRL", valid, p, radius));

    bool found_preferred = false;
    best = DubinsCandidate();

    for (const auto & candidate : candidates) {
      if (!candidate.valid) {
        continue;
      }
      if (!directionAccepts(direction, candidate.word)) {
        continue;
      }
      if (!found_preferred || candidate.cost < best.cost) {
        best = candidate;
        found_preferred = true;
      }
    }

    if (found_preferred) {
      return true;
    }

    // Fallback: if a requested initial turn side has no mathematical
    // solution, use the shortest valid Dubins path rather than publishing
    // a dangerous straight shortcut.
    bool found_any = false;
    for (const auto & candidate : candidates) {
      if (!candidate.valid) {
        continue;
      }
      if (!found_any || candidate.cost < best.cost) {
        best = candidate;
        found_any = true;
      }
    }

    return found_any;
  }

  static geometry_msgs::msg::PoseStamped makePose(
    const std_msgs::msg::Header & header,
    double x, double y, double yaw)
  {
    geometry_msgs::msg::PoseStamped pose;
    pose.header = header;
    pose.pose.position.x = x;
    pose.pose.position.y = y;
    pose.pose.position.z = 0.0;

    tf2::Quaternion q;
    q.setRPY(0.0, 0.0, yaw);
    pose.pose.orientation.x = q.x();
    pose.pose.orientation.y = q.y();
    pose.pose.orientation.z = q.z();
    pose.pose.orientation.w = q.w();
    return pose;
  }

  static void appendPose(
    nav_msgs::msg::Path & path,
    double x, double y, double yaw)
  {
    if (!path.poses.empty()) {
      const auto & last = path.poses.back().pose.position;
      if (std::hypot(last.x - x, last.y - y) < 1e-8) {
        // Keep the same position but update its orientation to the newest
        // segment heading. This is useful at turn_exit -> next straight.
        path.poses.back() = makePose(path.header, x, y, yaw);
        return;
      }
    }

    path.poses.push_back(makePose(path.header, x, y, yaw));
  }

  static void integrateMotion(
    char mode,
    double ds,
    double radius,
    double & x,
    double & y,
    double & yaw)
  {
    if (mode == 'S') {
      x += ds * std::cos(yaw);
      y += ds * std::sin(yaw);
      return;
    }

    const double curvature =
      (mode == 'L') ? (1.0 / radius) : (-1.0 / radius);
    const double new_yaw = yaw + curvature * ds;

    x +=
      (std::sin(new_yaw) - std::sin(yaw)) / curvature;
    y +=
      (-std::cos(new_yaw) + std::cos(yaw)) / curvature;
    yaw = new_yaw;
  }

  static void appendDubinsPath(
    nav_msgs::msg::Path & path,
    const geometry_msgs::msg::Point & start,
    double start_yaw,
    const geometry_msgs::msg::Point & goal,
    double goal_yaw,
    const TurnaroundSegment & turn)
  {
    DubinsCandidate candidate;
    if (!planDubins(
        start.x, start.y, start_yaw,
        goal.x, goal.y, goal_yaw,
        turn.min_turning_radius,
        turn.direction,
        candidate))
    {
      // This should be extremely rare. Do not silently connect the endpoints
      // by a straight line because that would violate the semantic turn.
      return;
    }

    const double sample_resolution =
      std::max(0.02, turn.resolution);

    double x = start.x;
    double y = start.y;
    double yaw = start_yaw;

    appendPose(path, x, y, yaw);

    for (size_t segment_index = 0;
         segment_index < 3;
         ++segment_index)
    {
      const char mode = candidate.word[segment_index];
      const double segment_length =
        candidate.params[segment_index] *
        turn.min_turning_radius;

      const int steps = std::max(
        1,
        static_cast<int>(
          std::ceil(segment_length / sample_resolution)));

      const double ds =
        segment_length / static_cast<double>(steps);

      for (int step = 0; step < steps; ++step) {
        integrateMotion(
          mode, ds, turn.min_turning_radius,
          x, y, yaw);
        appendPose(path, x, y, yaw);
      }
    }

    // Remove accumulated floating-point integration error at the exit.
    appendPose(path, goal.x, goal.y, goal_yaw);
  }

  double headingIntoPoint(size_t index) const
  {
    if (route_points_.empty()) {
      return 0.0;
    }

    if (index > 0) {
      const auto & a = route_points_[index - 1].point;
      const auto & b = route_points_[index].point;
      const double dx = b.x - a.x;
      const double dy = b.y - a.y;
      if (std::hypot(dx, dy) > 1e-8) {
        return std::atan2(dy, dx);
      }
    }

    if (index + 1 < route_points_.size()) {
      const auto & a = route_points_[index].point;
      const auto & b = route_points_[index + 1].point;
      return std::atan2(b.y - a.y, b.x - a.x);
    }

    return 0.0;
  }

  double headingOutOfPoint(size_t index) const
  {
    if (route_points_.empty()) {
      return 0.0;
    }

    if (index + 1 < route_points_.size()) {
      const auto & a = route_points_[index].point;
      const auto & b = route_points_[index + 1].point;
      const double dx = b.x - a.x;
      const double dy = b.y - a.y;
      if (std::hypot(dx, dy) > 1e-8) {
        return std::atan2(dy, dx);
      }
    }

    if (index > 0) {
      return headingIntoPoint(index);
    }

    return 0.0;
  }

  void appendStraightSegment(
    nav_msgs::msg::Path & path,
    const geometry_msgs::msg::Point & a,
    const geometry_msgs::msg::Point & b) const
  {
    const double dx = b.x - a.x;
    const double dy = b.y - a.y;
    const double distance = std::hypot(dx, dy);

    if (distance < 1e-8) {
      return;
    }

    const double yaw = std::atan2(dy, dx);
    const int segments = std::max(
      1,
      static_cast<int>(
        std::ceil(distance / resolution_)));

    for (int j = 0; j < segments; ++j) {
      const double ratio =
        static_cast<double>(j) /
        static_cast<double>(segments);

      appendPose(
        path,
        a.x + ratio * dx,
        a.y + ratio * dy,
        yaw);
    }
  }

  nav_msgs::msg::Path buildPath()
  {
    nav_msgs::msg::Path path;
    path.header.frame_id = frame_id_;
    path.header.stamp = now();

    if (route_points_.size() < 2) {
      return path;
    }

    for (size_t i = 0; i + 1 < route_points_.size(); ++i) {
      const auto & a = route_points_[i];
      const auto & b = route_points_[i + 1];

      const auto * turn = findTurnaround(a.id, b.id);

      if (turn != nullptr) {
        const double start_yaw = headingIntoPoint(i);
        const double end_yaw = headingOutOfPoint(i + 1);

        appendDubinsPath(
          path,
          a.point,
          start_yaw,
          b.point,
          end_yaw,
          *turn);
      } else {
        appendStraightSegment(path, a.point, b.point);
      }
    }

    const size_t last = route_points_.size() - 1;
    appendPose(
      path,
      route_points_[last].point.x,
      route_points_[last].point.y,
      headingIntoPoint(last));

    return path;
  }

  visualization_msgs::msg::MarkerArray buildMarkers()
  {
    visualization_msgs::msg::MarkerArray array;

    visualization_msgs::msg::Marker clear;
    clear.header.frame_id = frame_id_;
    clear.header.stamp = now();
    clear.action = visualization_msgs::msg::Marker::DELETEALL;
    array.markers.push_back(clear);

    auto semanticLabel = [](const std::string & type) -> std::string {
      if (type == "start") {
        return "START";
      }
      if (type == "hutch_stop") {
        return "STOP";
      }
      if (type == "turn_entry") {
        return "TURN_IN";
      }
      if (type == "turn_exit") {
        return "TURN_OUT";
      }
      if (type == "goal") {
        return "GOAL";
      }
      return "WAYPOINT";
    };

    for (size_t i = 0; i < route_points_.size(); ++i) {
      const auto & route_point = route_points_[i];

      visualization_msgs::msg::Marker dot;
      dot.header.frame_id = frame_id_;
      dot.header.stamp = now();
      dot.ns = "clicked_points";
      dot.id = route_point.id;
      dot.type = visualization_msgs::msg::Marker::SPHERE;
      dot.action = visualization_msgs::msg::Marker::ADD;
      dot.pose.position = route_point.point;
      dot.pose.orientation.w = 1.0;
      dot.scale.x = 0.27;
      dot.scale.y = 0.27;
      dot.scale.z = 0.27;

      // Semantic colors:
      // START green, WAYPOINT blue, STOP red,
      // TURN_IN yellow, TURN_OUT orange/cyan, GOAL purple.
      if (route_point.type == "start") {
        dot.color.r = 0.10f;
        dot.color.g = 1.00f;
        dot.color.b = 0.20f;
      } else if (route_point.type == "hutch_stop") {
        dot.color.r = 1.00f;
        dot.color.g = 0.10f;
        dot.color.b = 0.10f;
      } else if (route_point.type == "turn_entry") {
        dot.color.r = 1.00f;
        dot.color.g = 0.85f;
        dot.color.b = 0.00f;
      } else if (route_point.type == "turn_exit") {
        dot.color.r = 1.00f;
        dot.color.g = 0.45f;
        dot.color.b = 0.05f;
      } else if (route_point.type == "goal") {
        dot.color.r = 0.75f;
        dot.color.g = 0.20f;
        dot.color.b = 1.00f;
      } else {
        dot.color.r = 0.10f;
        dot.color.g = 0.55f;
        dot.color.b = 1.00f;
      }
      dot.color.a = 1.0f;
      array.markers.push_back(dot);

      visualization_msgs::msg::Marker text;
      text.header = dot.header;
      text.ns = "point_labels";
      text.id = 10000 + route_point.id;
      text.type = visualization_msgs::msg::Marker::TEXT_VIEW_FACING;
      text.action = visualization_msgs::msg::Marker::ADD;
      text.pose.position = route_point.point;
      text.pose.position.z = 0.48;
      text.pose.orientation.w = 1.0;
      text.scale.z = 0.26;
      text.color.r = 1.0f;
      text.color.g = 1.0f;
      text.color.b = 1.0f;
      text.color.a = 1.0f;
      text.text =
        "P" + std::to_string(route_point.id) + " " +
        semanticLabel(route_point.type);
      array.markers.push_back(text);
    }

    return array;
  }

  void publishAll()
  {
    marker_pub_->publish(buildMarkers());
    path_pub_->publish(buildPath());
  }

  void clearPath(
    const std::shared_ptr<std_srvs::srv::Trigger::Request>,
    std::shared_ptr<std_srvs::srv::Trigger::Response> response)
  {
    route_points_.clear();
    turnarounds_.clear();
    publishAll();

    response->success = true;
    response->message =
      "All semantic points/turnarounds cleared in memory. "
      "Saved YAML was preserved.";

    RCLCPP_INFO(
      get_logger(),
      "Cleared all semantic points/turnarounds in memory; "
      "saved route kept at '%s'.",
      route_file_.c_str());
  }

  void undoPoint(
    const std::shared_ptr<std_srvs::srv::Trigger::Request>,
    std::shared_ptr<std_srvs::srv::Trigger::Response> response)
  {
    if (route_points_.empty()) {
      response->success = false;
      response->message = "No point to undo.";
      return;
    }

    const int removed_id = route_points_.back().id;
    route_points_.pop_back();

    turnarounds_.erase(
      std::remove_if(
        turnarounds_.begin(),
        turnarounds_.end(),
        [removed_id](const TurnaroundSegment & turn) {
          return
            turn.from_id == removed_id ||
            turn.to_id == removed_id;
        }),
      turnarounds_.end());

    publishAll();

    std::string save_note;
    if (auto_save_) {
      std::string message;
      if (saveRouteToDisk(message)) {
        save_note = " Auto-saved.";
        RCLCPP_INFO(
          get_logger(),
          "Auto-save after undo: %s", message.c_str());
      } else {
        save_note = " Auto-save FAILED: " + message;
        RCLCPP_ERROR(
          get_logger(),
          "Auto-save after undo failed: %s",
          message.c_str());
      }
    }

    response->success = true;
    response->message =
      "Removed P" + std::to_string(removed_id) + "." + save_note;

    RCLCPP_INFO(
      get_logger(),
      "Undo: %zu semantic point(s) remain.",
      route_points_.size());
  }

  void saveRouteService(
    const std::shared_ptr<std_srvs::srv::Trigger::Request>,
    std::shared_ptr<std_srvs::srv::Trigger::Response> response)
  {
    std::string message;
    response->success = saveRouteToDisk(message);
    response->message = message;

    if (response->success) {
      RCLCPP_INFO(
        get_logger(), "Manual save: %s", message.c_str());
    } else {
      RCLCPP_ERROR(
        get_logger(), "Manual save failed: %s", message.c_str());
    }
  }

  void loadRouteService(
    const std::shared_ptr<std_srvs::srv::Trigger::Request>,
    std::shared_ptr<std_srvs::srv::Trigger::Response> response)
  {
    std::string message;
    response->success = loadRouteFromDisk(message);
    response->message = message;

    if (response->success) {
      RCLCPP_INFO(
        get_logger(), "Manual load: %s", message.c_str());
    } else {
      RCLCPP_ERROR(
        get_logger(), "Manual load failed: %s", message.c_str());
    }
  }
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<RVizPathEditor>());
  rclcpp::shutdown();
  return 0;
}
