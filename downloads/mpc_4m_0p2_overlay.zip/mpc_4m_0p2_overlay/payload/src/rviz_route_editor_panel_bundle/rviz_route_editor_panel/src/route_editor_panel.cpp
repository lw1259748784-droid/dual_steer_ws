#include "rviz_route_editor_panel/route_editor_panel.hpp"

#include <QButtonGroup>
#include <QDoubleSpinBox>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QMetaObject>
#include <QPushButton>
#include <QRadioButton>
#include <QVBoxLayout>

#include <pluginlib/class_list_macros.hpp>
#include <rviz_common/display_context.hpp>
#include <rviz_common/ros_integration/ros_node_abstraction_iface.hpp>

namespace rviz_route_editor_panel
{

RouteEditorPanel::RouteEditorPanel(QWidget * parent)
: rviz_common::Panel(parent)
{
  auto * main_layout = new QVBoxLayout();

  auto * title = new QLabel("<b>Route Editor</b>");
  main_layout->addWidget(title);

  auto * help = new QLabel(
    "操作顺序：<b>选类型 → 顶部 Publish Point → 在地图点一下</b><br>"
    "TURN_IN 后应直接点 TURN_OUT，中间不要再人工打点。");
  help->setWordWrap(true);
  main_layout->addWidget(help);

  current_type_label_ = new QLabel("当前类型：WAYPOINT");
  main_layout->addWidget(current_type_label_);

  // ------------------------------------------------------------
  // Point type
  // ------------------------------------------------------------
  auto * type_box = new QGroupBox("当前打点类型");
  auto * type_layout = new QGridLayout();
  point_type_group_ = new QButtonGroup(this);

  start_radio_ = new QRadioButton("START 起点");
  waypoint_radio_ = new QRadioButton("WAYPOINT 普通点");
  stop_radio_ = new QRadioButton("STOP 喂奶停车点");
  turn_in_radio_ = new QRadioButton("TURN_IN 转弯入口");
  turn_out_radio_ = new QRadioButton("TURN_OUT 转弯出口");
  goal_radio_ = new QRadioButton("GOAL 终点");

  point_type_group_->addButton(start_radio_);
  point_type_group_->addButton(waypoint_radio_);
  point_type_group_->addButton(stop_radio_);
  point_type_group_->addButton(turn_in_radio_);
  point_type_group_->addButton(turn_out_radio_);
  point_type_group_->addButton(goal_radio_);

  type_layout->addWidget(start_radio_, 0, 0);
  type_layout->addWidget(waypoint_radio_, 0, 1);
  type_layout->addWidget(stop_radio_, 1, 0);
  type_layout->addWidget(turn_in_radio_, 1, 1);
  type_layout->addWidget(turn_out_radio_, 2, 0);
  type_layout->addWidget(goal_radio_, 2, 1);
  type_box->setLayout(type_layout);

  waypoint_radio_->setChecked(true);
  main_layout->addWidget(type_box);

  connect(start_radio_, &QRadioButton::clicked, this, [this]() {
    setPointType("start");
  });
  connect(waypoint_radio_, &QRadioButton::clicked, this, [this]() {
    setPointType("waypoint");
  });
  connect(stop_radio_, &QRadioButton::clicked, this, [this]() {
    setPointType("hutch_stop");
  });
  connect(turn_in_radio_, &QRadioButton::clicked, this, [this]() {
    setPointType("turn_entry");
  });
  connect(turn_out_radio_, &QRadioButton::clicked, this, [this]() {
    setPointType("turn_exit");
  });
  connect(goal_radio_, &QRadioButton::clicked, this, [this]() {
    setPointType("goal");
  });

  // ------------------------------------------------------------
  // Turnaround parameters
  // ------------------------------------------------------------
  auto * turn_box = new QGroupBox("自动转弯参数");
  auto * turn_layout = new QGridLayout();

  left_radio_ = new QRadioButton("Left 左转");
  right_radio_ = new QRadioButton("Right 右转");
  left_radio_->setChecked(true);

  turn_layout->addWidget(new QLabel("方向"), 0, 0);
  turn_layout->addWidget(left_radio_, 0, 1);
  turn_layout->addWidget(right_radio_, 0, 2);

  radius_spin_ = new QDoubleSpinBox();
  radius_spin_->setRange(0.50, 20.0);
  radius_spin_->setDecimals(2);
  radius_spin_->setSingleStep(0.10);
  radius_spin_->setValue(2.80);
  radius_spin_->setSuffix(" m");

  speed_spin_ = new QDoubleSpinBox();
  speed_spin_->setRange(0.01, 2.0);
  speed_spin_->setDecimals(2);
  speed_spin_->setSingleStep(0.01);
  speed_spin_->setValue(0.20);
  speed_spin_->setSuffix(" m/s");

  resolution_spin_ = new QDoubleSpinBox();
  resolution_spin_->setRange(0.02, 1.0);
  resolution_spin_->setDecimals(2);
  resolution_spin_->setSingleStep(0.01);
  resolution_spin_->setValue(0.10);
  resolution_spin_->setSuffix(" m");

  turn_layout->addWidget(new QLabel("最小转弯半径"), 1, 0);
  turn_layout->addWidget(radius_spin_, 1, 1, 1, 2);
  turn_layout->addWidget(new QLabel("转弯速度"), 2, 0);
  turn_layout->addWidget(speed_spin_, 2, 1, 1, 2);
  turn_layout->addWidget(new QLabel("曲线分辨率"), 3, 0);
  turn_layout->addWidget(resolution_spin_, 3, 1, 1, 2);

  apply_turn_button_ = new QPushButton("应用转弯参数");
  turn_layout->addWidget(apply_turn_button_, 4, 0, 1, 3);

  turn_box->setLayout(turn_layout);
  main_layout->addWidget(turn_box);

  connect(
    apply_turn_button_, &QPushButton::clicked,
    this, &RouteEditorPanel::applyTurnParameters);

  // ------------------------------------------------------------
  // Existing editor services
  // ------------------------------------------------------------
  auto * edit_box = new QGroupBox("路线操作");
  auto * edit_layout = new QGridLayout();

  undo_button_ = new QPushButton("撤销上一点");
  clear_button_ = new QPushButton("清空当前路线");
  save_button_ = new QPushButton("保存路线");
  load_button_ = new QPushButton("加载路线");

  edit_layout->addWidget(undo_button_, 0, 0);
  edit_layout->addWidget(clear_button_, 0, 1);
  edit_layout->addWidget(save_button_, 1, 0);
  edit_layout->addWidget(load_button_, 1, 1);

  edit_box->setLayout(edit_layout);
  main_layout->addWidget(edit_box);

  status_label_ = new QLabel(
    "等待连接 /rviz_path_editor ...");
  status_label_->setWordWrap(true);
  main_layout->addWidget(status_label_);

  auto * legend = new QLabel(
    "<b>颜色：</b> START绿 / WAYPOINT蓝 / STOP红 / "
    "TURN_IN黄 / TURN_OUT橙 / GOAL紫");
  legend->setWordWrap(true);
  main_layout->addWidget(legend);

  main_layout->addStretch();
  setLayout(main_layout);

  connect(undo_button_, &QPushButton::clicked, this, [this]() {
    callTrigger(undo_client_, "Undo");
  });
  connect(clear_button_, &QPushButton::clicked, this, [this]() {
    callTrigger(clear_client_, "Clear");
  });
  connect(save_button_, &QPushButton::clicked, this, [this]() {
    callTrigger(save_client_, "Save");
  });
  connect(load_button_, &QPushButton::clicked, this, [this]() {
    callTrigger(load_client_, "Load");
  });
}

void RouteEditorPanel::onInitialize()
{
  auto ros_node_abstraction =
    getDisplayContext()->getRosNodeAbstraction().lock();

  if (!ros_node_abstraction) {
    setStatus("无法获取 RViz ROS 节点。");
    return;
  }

  node_ = ros_node_abstraction->get_raw_node();

  parameter_client_ =
    std::make_shared<rclcpp::AsyncParametersClient>(
      node_, "/rviz_path_editor");

  undo_client_ =
    node_->create_client<std_srvs::srv::Trigger>("/path_editor/undo");
  clear_client_ =
    node_->create_client<std_srvs::srv::Trigger>("/path_editor/clear");
  save_client_ =
    node_->create_client<std_srvs::srv::Trigger>("/path_editor/save");
  load_client_ =
    node_->create_client<std_srvs::srv::Trigger>("/path_editor/load");

  setPointType("waypoint");
  applyTurnParameters();

  setStatus(
    "面板已初始化。请选择点类型，然后点击 RViz 顶部 Publish Point。");
}

void RouteEditorPanel::setStatus(const QString & text)
{
  if (!status_label_) {
    return;
  }

  QMetaObject::invokeMethod(
    status_label_,
    [label = status_label_, text]() {
      label->setText(text);
    },
    Qt::QueuedConnection);
}

void RouteEditorPanel::setPointType(const std::string & type)
{
  QString display = "WAYPOINT";
  if (type == "start") {
    display = "START";
  } else if (type == "hutch_stop") {
    display = "STOP";
  } else if (type == "turn_entry") {
    display = "TURN_IN";
  } else if (type == "turn_exit") {
    display = "TURN_OUT";
  } else if (type == "goal") {
    display = "GOAL";
  }

  current_type_label_->setText("当前类型：" + display);

  if (!parameter_client_) {
    return;
  }

  if (!parameter_client_->service_is_ready()) {
    setStatus(
      "参数服务尚未就绪：请确认 /rviz_path_editor 已启动。");
    return;
  }

  std::vector<rclcpp::Parameter> parameters;
  parameters.emplace_back("current_point_type", type);
  parameter_client_->set_parameters(parameters);

  setStatus(
    "已选择 " + display +
    "。现在点击顶部 Publish Point，再在地图中点一下。");
}

void RouteEditorPanel::applyTurnParameters()
{
  if (!parameter_client_) {
    return;
  }

  if (!parameter_client_->service_is_ready()) {
    setStatus(
      "参数服务尚未就绪：请确认 /rviz_path_editor 已启动。");
    return;
  }

  const std::string direction =
    left_radio_->isChecked() ? "left" : "right";

  std::vector<rclcpp::Parameter> parameters;
  parameters.emplace_back("turn_direction", direction);
  parameters.emplace_back(
    "turn_min_turning_radius", radius_spin_->value());
  parameters.emplace_back(
    "turn_speed_limit", speed_spin_->value());
  parameters.emplace_back(
    "turn_resolution", resolution_spin_->value());

  parameter_client_->set_parameters(parameters);

  setStatus(
    QString("转弯参数已应用：%1，Rmin=%2 m，速度=%3 m/s")
      .arg(QString::fromStdString(direction))
      .arg(radius_spin_->value(), 0, 'f', 2)
      .arg(speed_spin_->value(), 0, 'f', 2));
}

void RouteEditorPanel::callTrigger(
  const rclcpp::Client<std_srvs::srv::Trigger>::SharedPtr & client,
  const QString & action_name)
{
  if (!client) {
    setStatus(action_name + " 服务客户端尚未初始化。");
    return;
  }

  if (!client->service_is_ready()) {
    setStatus(
      action_name +
      " 服务不可用，请确认 /rviz_path_editor 正在运行。");
    return;
  }

  auto request =
    std::make_shared<std_srvs::srv::Trigger::Request>();

  client->async_send_request(
    request,
    [this, action_name](
      rclcpp::Client<std_srvs::srv::Trigger>::SharedFuture future)
    {
      try {
        const auto response = future.get();
        const QString message =
          action_name +
          (response->success ? " 成功：" : " 失败：") +
          QString::fromStdString(response->message);
        setStatus(message);
      } catch (const std::exception & e) {
        setStatus(
          action_name + " 异常：" +
          QString::fromStdString(e.what()));
      }
    });
}

}  // namespace rviz_route_editor_panel

PLUGINLIB_EXPORT_CLASS(
  rviz_route_editor_panel::RouteEditorPanel,
  rviz_common::Panel)
