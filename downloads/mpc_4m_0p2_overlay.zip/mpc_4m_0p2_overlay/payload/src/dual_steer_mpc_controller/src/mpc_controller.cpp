#include "dual_steer_mpc_controller/mpc_controller.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <utility>

#include "nav2_core/exceptions.hpp"
#include "nav2_costmap_2d/cost_values.hpp"
#include "nav2_costmap_2d/costmap_filters/filter_values.hpp"
#include "nav2_util/node_utils.hpp"
#include "pluginlib/class_list_macros.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2/utils.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"

namespace dual_steer_mpc_controller
{

using nav2_util::declare_parameter_if_not_declared;

void MPCController::configure(
  const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
  std::string name,
  std::shared_ptr<tf2_ros::Buffer> tf,
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
{
  auto node = parent.lock();
  if (!node) {
    throw nav2_core::PlannerException("DualSteerMPC: unable to lock lifecycle node");
  }

  node_ = parent;
  plugin_name_ = std::move(name);
  tf_ = std::move(tf);
  costmap_ros_ = std::move(costmap_ros);
  costmap_ = costmap_ros_->getCostmap();
  logger_ = node->get_logger();
  clock_ = node->get_clock();

  declareAndLoadParameters(node);

  collision_checker_ = std::make_unique<
    nav2_costmap_2d::FootprintCollisionChecker<nav2_costmap_2d::Costmap2D *>>(costmap_);
  collision_checker_->setCostmap(costmap_);

  predicted_path_pub_ = node->create_publisher<nav_msgs::msg::Path>("mpc_predicted_path", 1);
  reference_path_pub_ = node->create_publisher<nav_msgs::msg::Path>("mpc_reference_path", 1);

  controls_.assign(static_cast<std::size_t>(horizon_steps_), Control{desired_speed_, 0.0});

  RCLCPP_INFO(
    logger_,
    "[%s] DualSteer MPC TRACKING-v2 configured: L=%.2fm Rmin=%.2fm kappa_max=%.3f 1/m, "
    "N=%d dt=%.2fs horizon=%.2fs, speed=%.2f m/s",
    plugin_name_.c_str(), wheelbase_, min_turning_radius_, max_curvature_,
    horizon_steps_, model_dt_, horizon_steps_ * model_dt_, desired_speed_);
}

void MPCController::declareAndLoadParameters(
  const rclcpp_lifecycle::LifecycleNode::SharedPtr & node)
{
  auto declare_double = [&](const std::string & key, double value) {
      declare_parameter_if_not_declared(
        node, plugin_name_ + "." + key, rclcpp::ParameterValue(value));
    };
  auto declare_int = [&](const std::string & key, int value) {
      declare_parameter_if_not_declared(
        node, plugin_name_ + "." + key, rclcpp::ParameterValue(value));
    };

  declare_double("wheelbase", 1.70);
  declare_double("min_turning_radius", 2.80);
  declare_double("desired_speed", 0.20);
  declare_double("max_speed", 0.20);
  declare_double("min_speed", 0.0);
  declare_double("max_accel", 0.20);
  declare_double("max_decel", 0.30);
  declare_double("max_curvature_rate", 0.25);

  declare_int("horizon_steps", 40);
  declare_double("model_dt", 0.20);
  declare_double("control_dt", 0.10);
  declare_int("optimization_iterations", 5);
  declare_int("curvature_block_size", 5);
  declare_double("velocity_search_step", 0.03);
  declare_double("curvature_search_step", 0.06);
  declare_double("search_decay", 0.5);

  declare_double("reference_path_length", 4.0);
  declare_double("max_robot_pose_search_dist", 2.5);
  declare_double("max_reference_deviation_m", 1.5);
  declare_double("seed_lookahead_dist", 4.00);
  declare_double("transform_tolerance", 0.20);
  declare_double("slow_down_distance", 1.50);
  declare_double("stop_distance", 0.10);
  declare_double("minimum_tracking_speed", 0.10);
  declare_double("cross_track_slowdown_m", 0.40);
  declare_double("heading_slowdown_rad", 0.50);
  declare_double("max_heading_error_rad", 1.22);

  declare_double("w_cte", 60.0);
  declare_double("w_heading", 15.0);
  declare_double("w_speed", 2.0);
  declare_double("w_curvature", 1.0);
  declare_double("w_curvature_change", 2.0);
  declare_double("w_accel", 3.0);
  declare_double("w_terminal_position", 8.0);
  declare_double("w_terminal_heading", 4.0);
  declare_double("w_obstacle", 80.0);

  node->get_parameter(plugin_name_ + ".wheelbase", wheelbase_);
  node->get_parameter(plugin_name_ + ".min_turning_radius", min_turning_radius_);
  node->get_parameter(plugin_name_ + ".desired_speed", desired_speed_);
  base_desired_speed_ = desired_speed_;
  node->get_parameter(plugin_name_ + ".max_speed", max_speed_);
  node->get_parameter(plugin_name_ + ".min_speed", min_speed_);
  node->get_parameter(plugin_name_ + ".max_accel", max_accel_);
  node->get_parameter(plugin_name_ + ".max_decel", max_decel_);
  node->get_parameter(plugin_name_ + ".max_curvature_rate", max_curvature_rate_);

  node->get_parameter(plugin_name_ + ".horizon_steps", horizon_steps_);
  node->get_parameter(plugin_name_ + ".model_dt", model_dt_);
  node->get_parameter(plugin_name_ + ".control_dt", control_dt_);
  node->get_parameter(plugin_name_ + ".optimization_iterations", optimization_iterations_);
  node->get_parameter(plugin_name_ + ".curvature_block_size", curvature_block_size_);
  node->get_parameter(plugin_name_ + ".velocity_search_step", velocity_search_step_);
  node->get_parameter(plugin_name_ + ".curvature_search_step", curvature_search_step_);
  node->get_parameter(plugin_name_ + ".search_decay", search_decay_);

  node->get_parameter(plugin_name_ + ".reference_path_length", reference_path_length_);
  node->get_parameter(plugin_name_ + ".max_robot_pose_search_dist", max_robot_pose_search_dist_);
  node->get_parameter(plugin_name_ + ".max_reference_deviation_m", max_reference_deviation_m_);
  node->get_parameter(plugin_name_ + ".seed_lookahead_dist", seed_lookahead_dist_);
  node->get_parameter(plugin_name_ + ".transform_tolerance", transform_tolerance_sec_);
  node->get_parameter(plugin_name_ + ".slow_down_distance", slow_down_distance_);
  node->get_parameter(plugin_name_ + ".stop_distance", stop_distance_);
  node->get_parameter(plugin_name_ + ".minimum_tracking_speed", minimum_tracking_speed_);
  node->get_parameter(plugin_name_ + ".cross_track_slowdown_m", cross_track_slowdown_m_);
  node->get_parameter(plugin_name_ + ".heading_slowdown_rad", heading_slowdown_rad_);
  node->get_parameter(plugin_name_ + ".max_heading_error_rad", max_heading_error_rad_);

  node->get_parameter(plugin_name_ + ".w_cte", w_cte_);
  node->get_parameter(plugin_name_ + ".w_heading", w_heading_);
  node->get_parameter(plugin_name_ + ".w_speed", w_speed_);
  node->get_parameter(plugin_name_ + ".w_curvature", w_curvature_);
  node->get_parameter(plugin_name_ + ".w_curvature_change", w_curvature_change_);
  node->get_parameter(plugin_name_ + ".w_accel", w_accel_);
  node->get_parameter(plugin_name_ + ".w_terminal_position", w_terminal_position_);
  node->get_parameter(plugin_name_ + ".w_terminal_heading", w_terminal_heading_);
  node->get_parameter(plugin_name_ + ".w_obstacle", w_obstacle_);

  horizon_steps_ = std::max(horizon_steps_, 3);
  optimization_iterations_ = std::max(optimization_iterations_, 1);
  model_dt_ = std::max(model_dt_, 0.02);
  control_dt_ = clamp(control_dt_, 0.02, model_dt_);
  curvature_block_size_ = std::max(curvature_block_size_, 1);
  min_turning_radius_ = std::max(min_turning_radius_, 0.20);
  max_curvature_ = 1.0 / min_turning_radius_;
  max_speed_ = std::max(max_speed_, 0.01);
  desired_speed_ = clamp(desired_speed_, 0.0, max_speed_);
  base_desired_speed_ = desired_speed_;
  min_speed_ = clamp(min_speed_, 0.0, max_speed_);
  minimum_tracking_speed_ = clamp(minimum_tracking_speed_, min_speed_, max_speed_);
  max_accel_ = std::max(max_accel_, 0.01);
  max_decel_ = std::max(max_decel_, 0.01);
  max_curvature_rate_ = std::max(max_curvature_rate_, 0.01);
  curvature_search_step_ = std::max(curvature_search_step_, 0.001);
  search_decay_ = clamp(search_decay_, 0.1, 1.0);
  cross_track_slowdown_m_ = std::max(cross_track_slowdown_m_, 0.01);
  heading_slowdown_rad_ = std::max(heading_slowdown_rad_, 0.01);
  max_heading_error_rad_ = clamp(max_heading_error_rad_, 0.10, 1.57);
  transform_tolerance_ = tf2::durationFromSec(transform_tolerance_sec_);
}

void MPCController::cleanup()
{
  std::lock_guard<std::mutex> lock(mutex_);
  predicted_path_pub_.reset();
  reference_path_pub_.reset();
  collision_checker_.reset();
  global_plan_ = nav_msgs::msg::Path();
  plan_progress_segment_ = 0;
  controls_.clear();
  have_solution_ = false;
  last_curvature_ = 0.0;
  last_speed_command_ = 0.0;
  RCLCPP_INFO(logger_, "[%s] DualSteer MPC cleaned up", plugin_name_.c_str());
}

void MPCController::activate()
{
  if (predicted_path_pub_) {
    predicted_path_pub_->on_activate();
  }
  if (reference_path_pub_) {
    reference_path_pub_->on_activate();
  }
  RCLCPP_INFO(logger_, "[%s] DualSteer MPC activated", plugin_name_.c_str());
}

void MPCController::deactivate()
{
  if (predicted_path_pub_) {
    predicted_path_pub_->on_deactivate();
  }
  if (reference_path_pub_) {
    reference_path_pub_->on_deactivate();
  }
  RCLCPP_INFO(logger_, "[%s] DualSteer MPC deactivated", plugin_name_.c_str());
}

void MPCController::setPlan(const nav_msgs::msg::Path & path)
{
  std::lock_guard<std::mutex> lock(mutex_);
  global_plan_ = path;
  // The planner trims a new plan to the current route progress at every replan.
  plan_progress_segment_ = 0;
  if (global_plan_.poses.size() < 2) {
    have_solution_ = false;
  }
}

void MPCController::setSpeedLimit(const double & speed_limit, const bool & percentage)
{
  std::lock_guard<std::mutex> lock(mutex_);
  if (speed_limit == nav2_costmap_2d::NO_SPEED_LIMIT) {
    desired_speed_ = base_desired_speed_;
    return;
  }

  if (percentage) {
    desired_speed_ = clamp(base_desired_speed_ * speed_limit / 100.0, 0.0, max_speed_);
  } else {
    desired_speed_ = clamp(speed_limit, 0.0, max_speed_);
  }
}

geometry_msgs::msg::TwistStamped MPCController::computeVelocityCommands(
  const geometry_msgs::msg::PoseStamped & pose,
  const geometry_msgs::msg::Twist & velocity,
  nav2_core::GoalChecker * /*goal_checker*/)
{
  std::lock_guard<std::mutex> lock(mutex_);

  if (global_plan_.poses.size() < 2) {
    throw nav2_core::PlannerException("DualSteerMPC: received plan with fewer than 2 poses");
  }

  nav_msgs::msg::Path reference = buildReferencePath(pose);
  if (reference.poses.size() < 2) {
    throw nav2_core::PlannerException("DualSteerMPC: no usable local reference path");
  }

  if (reference_path_pub_ && reference_path_pub_->is_activated()) {
    reference_path_pub_->publish(reference);
  }

  geometry_msgs::msg::PoseStamped goal = transformGoalToCostmapFrame(pose);
  const double goal_distance = distanceToGoal(pose, goal);

  geometry_msgs::msg::TwistStamped output;
  output.header = pose.header;

  if (goal_distance <= stop_distance_) {
    output.twist.linear.x = 0.0;
    output.twist.angular.z = 0.0;
    last_curvature_ = 0.0;
    last_speed_command_ = 0.0;
    have_solution_ = false;
    return output;
  }

  State initial;
  initial.x = pose.pose.position.x;
  initial.y = pose.pose.position.y;
  initial.yaw = tf2::getYaw(pose.pose.orientation);
  initial.v = std::max(0.0, velocity.linear.x);
  if (!std::isfinite(initial.x) || !std::isfinite(initial.y) ||
    !std::isfinite(initial.yaw) || !std::isfinite(velocity.linear.x))
  {
    throw nav2_core::PlannerException("DualSteerMPC: invalid vehicle pose or speed");
  }

  const ReferenceMatch current_match = matchReference(reference, initial.x, initial.y, 0);
  const double heading_error = normalizeAngle(initial.yaw - current_match.yaw);
  if (std::abs(heading_error) > max_heading_error_rad_) {
    throw nav2_core::PlannerException(
      "DualSteerMPC: heading error exceeds the forward-tracking limit; align the vehicle first");
  }

  const double target_speed = trackingSpeed(
    std::min(desired_speed_, max_speed_), goal_distance,
    current_match.distance, heading_error);
  if (target_speed <= 1e-6) {
    // A zero speed limit is an explicit stop. Never raise it to the tracking floor.
    output.twist.linear.x = 0.0;
    output.twist.angular.z = 0.0;
    last_curvature_ = 0.0;
    last_speed_command_ = 0.0;
    have_solution_ = false;
    return output;
  }

  // The CAN driver centers the wheels when stopped. Do not retain a stale
  // curvature from the preceding feeding pause or cancelled navigation task.
  if (initial.v < 0.01) {
    last_curvature_ = 0.0;
    have_solution_ = false;
  }

  // Warm start by shifting the previous solution.  On the first cycle use a
  // geometry-derived curvature seed, but all subsequent commands come from
  // the receding-horizon optimizer.
  if (controls_.size() != static_cast<std::size_t>(horizon_steps_)) {
    controls_.assign(static_cast<std::size_t>(horizon_steps_), Control{target_speed, 0.0});
    have_solution_ = false;
  }

  if (have_solution_) {
    for (std::size_t i = 0; i + 1 < controls_.size(); ++i) {
      controls_[i] = controls_[i + 1];
    }
    controls_.back() = controls_[controls_.size() - 2];
    for (auto & u : controls_) {
      u.v = clamp(u.v, min_speed_, target_speed);
    }
  } else {
    const double seed_kappa = referenceSeedCurvature(pose, reference);
    for (auto & u : controls_) {
      u.v = target_speed;
      u.kappa = seed_kappa;
    }
  }

  std::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> costmap_lock(*(costmap_->getMutex()));
  optimize(initial, reference, target_speed);
  projectControlSequence(controls_, last_speed_command_, last_curvature_);

  nav_msgs::msg::Path predicted;
  const double solution_cost = rolloutCost(
    initial, controls_, reference, target_speed, &predicted);
  if (!std::isfinite(solution_cost)) {
    last_speed_command_ = 0.0;
    last_curvature_ = 0.0;
    have_solution_ = false;
    throw nav2_core::PlannerException(
      "DualSteerMPC: no collision-free feasible prediction; stopping");
  }
  if (predicted_path_pub_ && predicted_path_pub_->is_activated()) {
    predicted_path_pub_->publish(predicted);
  }

  const Control command = controls_.front();
  output.twist.linear.x = command.v;
  output.twist.linear.y = 0.0;
  output.twist.angular.z = command.v * command.kappa;

  last_curvature_ = command.kappa;
  last_speed_command_ = command.v;
  have_solution_ = true;

  constexpr double kRadiansToDegrees = 57.29577951308232;
  RCLCPP_INFO_THROTTLE(
    logger_, *clock_, 1000,
    "MPC tracking: cte=%+.3f m heading=%+.1f deg target_v=%.3f v=%.3f "
    "kappa=%+.3f wz=%+.4f",
    current_match.signed_distance, heading_error * kRadiansToDegrees,
    target_speed, output.twist.linear.x, command.kappa, output.twist.angular.z);

  RCLCPP_DEBUG(
    logger_,
    "MPC cmd: v=%.3f m/s kappa=%.3f 1/m wz=%.3f rad/s goal=%.2fm",
    output.twist.linear.x, command.kappa, output.twist.angular.z, goal_distance);

  return output;
}

nav_msgs::msg::Path MPCController::buildReferencePath(
  const geometry_msgs::msg::PoseStamped & robot_pose)
{
  if (global_plan_.poses.empty()) {
    throw nav2_core::PlannerException("DualSteerMPC: global plan is empty");
  }

  geometry_msgs::msg::PoseStamped robot_in_plan;
  if (!transformPose(global_plan_.header.frame_id, robot_pose, robot_in_plan)) {
    throw nav2_core::PlannerException("DualSteerMPC: cannot transform robot into global plan frame");
  }

  // Search from the saved progress cursor, not from the first 10 m of the
  // entire plan on every control cycle. A short *along-route* window stops a
  // tight U-turn from snapping the reference to its nearby return branch.
  const std::size_t first = std::min(plan_progress_segment_, global_plan_.poses.size() - 2);
  std::size_t nearest_segment = first;
  double nearest_t = 0.0;
  double best_d2 = std::numeric_limits<double>::max();
  double searched_length = 0.0;
  for (std::size_t i = first; i + 1 < global_plan_.poses.size(); ++i) {
    const auto & a = global_plan_.poses[i].pose.position;
    const auto & b = global_plan_.poses[i + 1].pose.position;
    const double dx = b.x - a.x;
    const double dy = b.y - a.y;
    const double len2 = dx * dx + dy * dy;
    if (i > first && max_robot_pose_search_dist_ > 0.0 &&
      searched_length > max_robot_pose_search_dist_)
    {
      break;
    }
    if (len2 > 1e-10) {
      const double t = clamp(
        ((robot_in_plan.pose.position.x - a.x) * dx +
        (robot_in_plan.pose.position.y - a.y) * dy) / len2, 0.0, 1.0);
      const double ex = robot_in_plan.pose.position.x - (a.x + t * dx);
      const double ey = robot_in_plan.pose.position.y - (a.y + t * dy);
      const double d2 = ex * ex + ey * ey;
      if (d2 < best_d2) {
        best_d2 = d2;
        nearest_segment = i;
        nearest_t = t;
      }
    }
    searched_length += std::sqrt(len2);
  }
  if (!std::isfinite(best_d2)) {
    throw nav2_core::PlannerException("DualSteerMPC: path has no valid segments");
  }
  const double deviation = std::sqrt(best_d2);
  if (max_reference_deviation_m_ > 0.0 && deviation > max_reference_deviation_m_) {
    throw nav2_core::PlannerException(
      "DualSteerMPC: deviation " + std::to_string(deviation) +
      " m exceeds safe limit; stopping instead of jumping to another route branch");
  }
  plan_progress_segment_ = nearest_segment;

  nav_msgs::msg::Path reference;
  reference.header.frame_id = costmap_ros_->getGlobalFrameID();
  reference.header.stamp = robot_pose.header.stamp;

  // Start at the orthogonal projection *on* the reference segment. Do not
  // prepend the off-route vehicle pose or force it toward the nearest vertex.
  const auto & a = global_plan_.poses[nearest_segment].pose.position;
  const auto & b = global_plan_.poses[nearest_segment + 1].pose.position;
  if (nearest_segment + 2 == global_plan_.poses.size()) {
    nearest_t = std::min(nearest_t, 0.99);
  }
  geometry_msgs::msg::PoseStamped projected = global_plan_.poses[nearest_segment];
  projected.header.frame_id = global_plan_.header.frame_id;
  projected.header.stamp = robot_in_plan.header.stamp;
  projected.pose.position.x = a.x + nearest_t * (b.x - a.x);
  projected.pose.position.y = a.y + nearest_t * (b.y - a.y);
  projected.pose.position.z = 0.0;
  tf2::Quaternion q;
  q.setRPY(0.0, 0.0, std::atan2(b.y - a.y, b.x - a.x));
  projected.pose.orientation = tf2::toMsg(q);

  geometry_msgs::msg::PoseStamped previous_transformed;
  if (!transformPose(reference.header.frame_id, projected, previous_transformed)) {
    throw nav2_core::PlannerException("DualSteerMPC: cannot transform projected reference start");
  }
  reference.poses.push_back(previous_transformed);
  double length = 0.0;
  for (std::size_t i = nearest_segment + 1; i < global_plan_.poses.size(); ++i) {
    geometry_msgs::msg::PoseStamped in = global_plan_.poses[i];
    in.header.frame_id = global_plan_.header.frame_id;
    in.header.stamp = robot_in_plan.header.stamp;
    geometry_msgs::msg::PoseStamped out;
    if (!transformPose(reference.header.frame_id, in, out)) {
      throw nav2_core::PlannerException("DualSteerMPC: cannot transform reference path point");
    }
    out.pose.position.z = 0.0;
    const double segment_length = std::hypot(
      out.pose.position.x - previous_transformed.pose.position.x,
      out.pose.position.y - previous_transformed.pose.position.y);
    // Retain one more point if necessary to form a valid segment near goal.
    if (reference.poses.size() >= 2 &&
      length + segment_length > reference_path_length_)
    {
      break;
    }
    reference.poses.push_back(out);
    length += segment_length;
    previous_transformed = out;
  }
  return reference;
}

geometry_msgs::msg::PoseStamped MPCController::transformGoalToCostmapFrame(
  const geometry_msgs::msg::PoseStamped & robot_pose) const
{
  geometry_msgs::msg::PoseStamped goal = global_plan_.poses.back();
  goal.header.frame_id = global_plan_.header.frame_id;
  goal.header.stamp = robot_pose.header.stamp;

  geometry_msgs::msg::PoseStamped transformed;
  if (!transformPose(costmap_ros_->getGlobalFrameID(), goal, transformed)) {
    throw nav2_core::PlannerException(
      "DualSteerMPC: cannot transform goal into costmap frame; refusing an unsafe distance check");
  }
  return transformed;
}

bool MPCController::transformPose(
  const std::string & target_frame,
  const geometry_msgs::msg::PoseStamped & in_pose,
  geometry_msgs::msg::PoseStamped & out_pose) const
{
  if (in_pose.header.frame_id == target_frame) {
    out_pose = in_pose;
    return true;
  }

  try {
    tf_->transform(in_pose, out_pose, target_frame, transform_tolerance_);
    out_pose.header.frame_id = target_frame;
    return true;
  } catch (const tf2::TransformException & ex) {
    RCLCPP_ERROR(logger_, "DualSteerMPC TF error: %s", ex.what());
    return false;
  }
}

MPCController::ReferenceMatch MPCController::matchReference(
  const nav_msgs::msg::Path & path,
  double x, double y,
  std::size_t start_segment) const
{
  ReferenceMatch best;
  best.distance = std::numeric_limits<double>::max();
  if (path.poses.size() < 2) {
    return best;
  }

  const std::size_t first = std::min(start_segment, path.poses.size() - 2);
  const std::size_t last = path.poses.size() - 2;

  for (std::size_t i = first; i <= last; ++i) {
    const auto & a = path.poses[i].pose.position;
    const auto & b = path.poses[i + 1].pose.position;
    const double vx = b.x - a.x;
    const double vy = b.y - a.y;
    const double len2 = vx * vx + vy * vy;
    if (len2 < 1e-9) {
      continue;
    }
    const double t = clamp(((x - a.x) * vx + (y - a.y) * vy) / len2, 0.0, 1.0);
    const double px = a.x + t * vx;
    const double py = a.y + t * vy;
    const double d = std::hypot(x - px, y - py);
    if (d < best.distance) {
      best.distance = d;
      best.yaw = std::atan2(vy, vx);
      best.signed_distance = -std::sin(best.yaw) * (x - px) +
        std::cos(best.yaw) * (y - py);
      best.segment = i;
    }
  }
  return best;
}

double MPCController::referenceSeedCurvature(
  const geometry_msgs::msg::PoseStamped & robot_pose,
  const nav_msgs::msg::Path & path) const
{
  if (path.poses.empty()) {
    return 0.0;
  }

  const double rx = robot_pose.pose.position.x;
  const double ry = robot_pose.pose.position.y;
  const double ryaw = tf2::getYaw(robot_pose.pose.orientation);

  std::size_t target_idx = path.poses.size() - 1;
  for (std::size_t i = 0; i < path.poses.size(); ++i) {
    const auto & p = path.poses[i].pose.position;
    if (std::hypot(p.x - rx, p.y - ry) >= seed_lookahead_dist_) {
      target_idx = i;
      break;
    }
  }

  const auto & p = path.poses[target_idx].pose.position;
  const double dx = p.x - rx;
  const double dy = p.y - ry;
  const double local_x = std::cos(ryaw) * dx + std::sin(ryaw) * dy;
  const double local_y = -std::sin(ryaw) * dx + std::cos(ryaw) * dy;
  const double l2 = local_x * local_x + local_y * local_y;
  if (l2 < 1e-6) {
    return 0.0;
  }

  const double kappa = 2.0 * local_y / l2;
  return clamp(kappa, -max_curvature_, max_curvature_);
}

double MPCController::trackingSpeed(
  double speed_limit, double goal_distance,
  double cross_track_error, double heading_error) const
{
  const double limit = clamp(speed_limit, 0.0, max_speed_);
  if (limit <= 1e-6 || goal_distance <= stop_distance_) {
    return 0.0;
  }
  // A forward-only chassis needs positive speed to correct heading/position.
  // Schedule speed outside the lateral optimizer instead of rewarding it for
  // avoiding movement whenever tracking error is initially large.
  const double floor = std::min(minimum_tracking_speed_, limit);
  const double scale = 1.0 / (
    1.0 + std::abs(cross_track_error) / cross_track_slowdown_m_ +
    std::abs(heading_error) / heading_slowdown_rad_);
  double target = std::max(floor, limit * scale);
  if (goal_distance < slow_down_distance_) {
    const double ratio = clamp(goal_distance / std::max(slow_down_distance_, 1e-3), 0.0, 1.0);
    target = std::min(target, std::max(floor, limit * ratio));
  }
  return std::min(target, limit);
}

void MPCController::optimize(
  const State & initial,
  const nav_msgs::msg::Path & reference,
  double target_speed)
{
  // Compare only feasible sequences, and retain exactly the sequence whose cost
  // was evaluated. Fixed speed profiles remove the off-route zero-speed minimum.
  double best_cost = std::numeric_limits<double>::infinity();
  auto consider = [&](std::vector<Control> candidate) {
      for (auto & u : candidate) {
        u.v = target_speed;
      }
      projectControlSequence(candidate, last_speed_command_, last_curvature_);
      const double cost = rolloutCost(initial, candidate, reference, target_speed, nullptr);
      if (cost < best_cost) {
        best_cost = cost;
        controls_ = std::move(candidate);
      }
    };

  consider(controls_);
  geometry_msgs::msg::PoseStamped pose;
  pose.pose.position.x = initial.x;
  pose.pose.position.y = initial.y;
  tf2::Quaternion q;
  q.setRPY(0.0, 0.0, initial.yaw);
  pose.pose.orientation = tf2::toMsg(q);
  const double seed = referenceSeedCurvature(pose, reference);
  consider(std::vector<Control>(controls_.size(), Control{target_speed, seed}));
  consider(std::vector<Control>(controls_.size(), Control{target_speed, 0.0}));

  for (int iteration = 0; iteration < optimization_iterations_; ++iteration) {
    const double dk = curvature_search_step_ * std::pow(search_decay_, iteration);
    // Moving an entire suffix permits a smooth steering change. Single-sample
    // descent alone pays the change penalty on both sides of every changed sample.
    for (std::size_t i = 0; i < controls_.size(); i += curvature_block_size_) {
      const auto base = controls_;
      for (const double direction : {-1.0, 1.0}) {
        auto candidate = base;
        for (std::size_t j = i; j < candidate.size(); ++j) {
          candidate[j].kappa += direction * dk;
        }
        consider(std::move(candidate));
      }
    }
    // Refine the immediate control block at single-sample resolution. Future
    // controls remain block-optimized to bound footprint checks per cycle.
    const std::size_t refine_count = std::min(
      controls_.size(), static_cast<std::size_t>(curvature_block_size_));
    for (std::size_t i = 0; i < refine_count; ++i) {
      const auto base = controls_;
      for (const double direction : {-1.0, 1.0}) {
        auto candidate = base;
        candidate[i].kappa += direction * dk;
        consider(std::move(candidate));
      }
    }
  }
  projectControlSequence(controls_, last_speed_command_, last_curvature_);
}

void MPCController::projectControlSequence(
  std::vector<Control> & sequence,
  double initial_speed,
  double initial_curvature) const
{
  double prev_v = clamp(initial_speed, 0.0, max_speed_);
  double prev_k = clamp(initial_curvature, -max_curvature_, max_curvature_);

  for (std::size_t i = 0; i < sequence.size(); ++i) {
    auto & u = sequence[i];
    const double step_dt = (i == 0) ? control_dt_ : model_dt_;
    const double up = max_accel_ * step_dt;
    const double down = max_decel_ * step_dt;
    const double dk = max_curvature_rate_ * step_dt;
    u.v = clamp(u.v, min_speed_, max_speed_);
    u.v = clamp(u.v, std::max(min_speed_, prev_v - down), std::min(max_speed_, prev_v + up));
    u.kappa = clamp(u.kappa, -max_curvature_, max_curvature_);
    u.kappa = clamp(u.kappa, prev_k - dk, prev_k + dk);
    prev_v = u.v;
    prev_k = u.kappa;
  }
}

double MPCController::rolloutCost(
  const State & initial,
  const std::vector<Control> & sequence,
  const nav_msgs::msg::Path & reference,
  double target_speed,
  nav_msgs::msg::Path * predicted_path) const
{
  State state = initial;
  std::size_t ref_segment = 0;
  // Smooth the upstream command against its preceding upstream command. The
  // measured speed can be reduced by an external feeding gate; using it as
  // the command slew origin would apply that scale repeatedly until stall.
  double previous_v = clamp(last_speed_command_, 0.0, max_speed_);
  double previous_kappa = last_curvature_;
  double total = 0.0;

  if (predicted_path) {
    predicted_path->header.frame_id = costmap_ros_->getGlobalFrameID();
    predicted_path->header.stamp = clock_->now();
    predicted_path->poses.clear();
  }

  for (std::size_t i = 0; i < sequence.size(); ++i) {
    const auto & raw_u = sequence[i];
    const double step_dt = (i == 0) ? control_dt_ : model_dt_;
    const double allowed_v_low = std::max(min_speed_, previous_v - max_decel_ * step_dt);
    const double allowed_v_high = std::min(max_speed_, previous_v + max_accel_ * step_dt);
    const double v = clamp(raw_u.v, allowed_v_low, allowed_v_high);
    const double kappa = clamp(
      raw_u.kappa,
      std::max(-max_curvature_, previous_kappa - max_curvature_rate_ * step_dt),
      std::min(max_curvature_, previous_kappa + max_curvature_rate_ * step_dt));

    state.x += v * std::cos(state.yaw) * model_dt_;
    state.y += v * std::sin(state.yaw) * model_dt_;
    state.yaw = normalizeAngle(state.yaw + v * kappa * model_dt_);
    state.v = v;

    const ReferenceMatch ref = matchReference(reference, state.x, state.y, ref_segment);
    ref_segment = std::max(ref_segment, ref.segment);

    const double heading_error = normalizeAngle(state.yaw - ref.yaw);
    const double speed_error = v - target_speed;
    const double dv = (v - previous_v) / step_dt;
    const double dk = (kappa - previous_kappa) / step_dt;
    const double obstacle_cost = obstacleCost(state.x, state.y, state.yaw);
    if (obstacle_cost >= 1000.0) {
      // A tracking-speed floor must never force movement through a lethal
      // footprint or beyond the costmap. No finite candidate means stop.
      return std::numeric_limits<double>::infinity();
    }

    total += w_cte_ * ref.distance * ref.distance;
    total += w_heading_ * heading_error * heading_error;
    total += w_speed_ * speed_error * speed_error;
    total += w_curvature_ * kappa * kappa;
    total += w_curvature_change_ * dk * dk;
    total += w_accel_ * dv * dv;
    total += w_obstacle_ * obstacle_cost;

    if (predicted_path) {
      geometry_msgs::msg::PoseStamped p;
      p.header = predicted_path->header;
      p.pose.position.x = state.x;
      p.pose.position.y = state.y;
      p.pose.position.z = 0.03;
      tf2::Quaternion q;
      q.setRPY(0.0, 0.0, state.yaw);
      p.pose.orientation = tf2::toMsg(q);
      predicted_path->poses.push_back(p);
    }

    previous_v = v;
    previous_kappa = kappa;
  }

  // Do not pull a 5 s prediction toward the end of a 4 m reference path:
  // the vehicle may reach only a fraction of the reference length over the horizon.
  // Use a reference target at the horizon's *reachable arc length* instead.
  const double reachable_length =
    std::max(0.0, target_speed) * model_dt_ * static_cast<double>(sequence.size());
  double remaining = reachable_length;
  double terminal_x = reference.poses.back().pose.position.x;
  double terminal_y = reference.poses.back().pose.position.y;
  double terminal_yaw = state.yaw;
  for (std::size_t i = 0; i + 1 < reference.poses.size(); ++i) {
    const auto & a = reference.poses[i].pose.position;
    const auto & b = reference.poses[i + 1].pose.position;
    const double dx = b.x - a.x;
    const double dy = b.y - a.y;
    const double seg_len = std::hypot(dx, dy);
    if (seg_len <= 1e-6) {
      continue;
    }
    terminal_yaw = std::atan2(dy, dx);
    if (remaining <= seg_len || i + 2 == reference.poses.size()) {
      const double t = clamp(remaining / seg_len, 0.0, 1.0);
      terminal_x = a.x + t * dx;
      terminal_y = a.y + t * dy;
      break;
    }
    remaining -= seg_len;
  }
  const double terminal_distance = std::hypot(
    state.x - terminal_x, state.y - terminal_y);
  const double terminal_heading_error = normalizeAngle(state.yaw - terminal_yaw);

  total += w_terminal_position_ * terminal_distance * terminal_distance;
  total += w_terminal_heading_ * terminal_heading_error * terminal_heading_error;
  return total;
}

double MPCController::obstacleCost(double x, double y, double yaw) const
{
  if (!collision_checker_) {
    return 0.0;
  }

  unsigned int mx = 0;
  unsigned int my = 0;
  if (!costmap_->worldToMap(x, y, mx, my)) {
    return 1000.0;
  }

  const double footprint_cost = collision_checker_->footprintCostAtPose(
    x, y, yaw, costmap_ros_->getRobotFootprint());

  if (footprint_cost >= static_cast<double>(nav2_costmap_2d::LETHAL_OBSTACLE)) {
    return 1000.0;
  }

  if (footprint_cost < 0.0 || footprint_cost == static_cast<double>(nav2_costmap_2d::NO_INFORMATION)) {
    return 0.0;
  }

  const double normalized = clamp(
    footprint_cost / static_cast<double>(nav2_costmap_2d::INSCRIBED_INFLATED_OBSTACLE),
    0.0, 1.0);
  return normalized * normalized;
}

double MPCController::distanceToGoal(
  const geometry_msgs::msg::PoseStamped & robot_pose,
  const geometry_msgs::msg::PoseStamped & goal) const
{
  return std::hypot(
    robot_pose.pose.position.x - goal.pose.position.x,
    robot_pose.pose.position.y - goal.pose.position.y);
}

double MPCController::normalizeAngle(double angle)
{
  constexpr double kPi = 3.14159265358979323846;
  while (angle > kPi) {
    angle -= 2.0 * kPi;
  }
  while (angle < -kPi) {
    angle += 2.0 * kPi;
  }
  return angle;
}

double MPCController::clamp(double value, double low, double high)
{
  return std::max(low, std::min(value, high));
}

}  // namespace dual_steer_mpc_controller

PLUGINLIB_EXPORT_CLASS(dual_steer_mpc_controller::MPCController, nav2_core::Controller)
