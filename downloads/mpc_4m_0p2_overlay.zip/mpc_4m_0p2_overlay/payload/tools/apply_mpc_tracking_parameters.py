#!/usr/bin/env python3
"""Create tracking parameter files using the vehicle's CURRENT configuration."""
import argparse
from pathlib import Path
import yaml


UPDATES = {
    'wheelbase': 1.70,
    'desired_speed': 0.20,
    'max_speed': 0.20,
    'min_speed': 0.0,
    'max_accel': 0.25,
    'max_decel': 0.35,
    'max_curvature_rate': 0.25,
    'horizon_steps': 40,
    'model_dt': 0.20,
    'optimization_iterations': 5,
    'curvature_block_size': 5,
    'curvature_search_step': 0.06,
    'search_decay': 0.5,
    'reference_path_length': 4.0,
    'max_robot_pose_search_dist': 2.5,
    'max_reference_deviation_m': 1.5,
    'seed_lookahead_dist': 4.00,
    'minimum_tracking_speed': 0.10,
    'cross_track_slowdown_m': 0.40,
    'heading_slowdown_rad': 0.50,
    'max_heading_error_rad': 1.22,
    'w_cte': 60.0,
    'w_heading': 15.0,
    'w_curvature': 1.0,
    'w_curvature_change': 2.0,
    'w_terminal_position': 8.0,
    'w_terminal_heading': 4.0,
}


def write_atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(
        '# Generated MPC tracking parameters; the original file is retained.\n' +
        yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding='utf-8')
    temp.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workspace', type=Path, default=Path.home() / 'dual_steer_ws')
    args = parser.parse_args()
    workspace = args.workspace.expanduser().resolve()
    nav_source = workspace / 'src/nav2_humble/config/nav2_params_dual_steer_no_map.yaml'
    can_source = workspace / 'src/ackermann_can_driver/config/feedback_params.yaml'
    nav = yaml.safe_load(nav_source.read_text(encoding='utf-8'))
    can = yaml.safe_load(can_source.read_text(encoding='utf-8'))
    controller = nav['controller_server']['ros__parameters']
    follow = controller['FollowPath']
    if follow.get('plugin') != 'dual_steer_mpc_controller::MPCController':
        raise ValueError('FollowPath is not the expected dual-steer MPC plugin')
    frequency = float(controller['controller_frequency'])
    if frequency < 5.0:
        raise ValueError('controller_frequency must be at least 5 Hz for this 0.20 s model')
    follow.update(UPDATES)
    follow['control_dt'] = 1.0 / frequency
    # Keep the smoother's forward limit aligned with the MPC speed cap.
    nav['velocity_smoother']['ros__parameters']['max_velocity'][0] = 0.20
    chassis = can['ackermann_can_controller']['ros__parameters']
    if chassis.get('steering_input_mode', 'yaw_rate') != 'yaw_rate':
        raise ValueError('CAN steering_input_mode must be yaw_rate')
    chassis['min_speed_for_steering_mps'] = 0.02
    nav_target = nav_source.with_name('nav2_params_dual_steer_mpc_tracking.yaml')
    can_target = can_source.with_name('feedback_params_mpc_tracking.yaml')
    write_atomic(nav_target, nav)
    write_atomic(can_target, can)
    print('Nav2 parameters:', nav_target)
    print('CAN parameters:', can_target)
    print('FollowPath.control_dt:', follow['control_dt'])
    print('Use these two paths explicitly as params_file launch arguments.')


if __name__ == '__main__':
    main()
